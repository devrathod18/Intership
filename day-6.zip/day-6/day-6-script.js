document.querySelector(".email-box button").addEventListener("click", () => {
    alert("Thanks for subscribing!");
});
